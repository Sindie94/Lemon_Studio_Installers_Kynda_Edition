#!/bin/sh
# Removes Lemon Studio (./uninstall.sh, or sudo ./uninstall.sh --system). Projects and settings are kept.
if [ "$1" = "--system" ]; then P=/usr/local; else P="$HOME/.local"; fi
rm -f "$P/bin/lemonstudio" "$P/share/applications/lemonstudio.desktop" "$P/share/icons/hicolor/256x256/apps/lemonstudio.png"
rm -rf "$P/share/doc/lemonstudio"
echo "Lemon Studio is removed. Your projects and settings are kept."
