#!/bin/sh
# Installs Lemon Studio 2026.11 (Kynda Edition) for this user: no administrator rights needed.
#   ./install.sh            installs in ~/.local (the app menu shows it)
#   sudo ./install.sh --system   installs for every user in /usr/local
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
if [ "$1" = "--system" ]; then P=/usr/local; else P="$HOME/.local"; fi
mkdir -p "$P/bin" "$P/share/applications" "$P/share/icons/hicolor/256x256/apps" "$P/share/doc/lemonstudio"
install -m 755 "$HERE/lemonstudio" "$P/bin/lemonstudio"
install -m 644 "$HERE/lemonstudio.png" "$P/share/icons/hicolor/256x256/apps/lemonstudio.png"
sed "s|^Exec=lemonstudio|Exec=$P/bin/lemonstudio|" "$HERE/lemonstudio.desktop" > "$P/share/applications/lemonstudio.desktop"
chmod 644 "$P/share/applications/lemonstudio.desktop"
cp "$HERE/READ ME.txt" "$HERE/LICENSE.txt" "$HERE/THIRD-PARTY-NOTICES.txt" "$P/share/doc/lemonstudio/"
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database -q "$P/share/applications" 2>/dev/null || true
command -v gtk-update-icon-cache >/dev/null 2>&1 && gtk-update-icon-cache -q -t "$P/share/icons/hicolor" 2>/dev/null || true
echo "Lemon Studio is installed: open it from your app menu, or run $P/bin/lemonstudio"
